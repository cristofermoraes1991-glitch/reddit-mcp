export default function Home() {
  return (
    <main style={{fontFamily:"system-ui",padding:"40px",maxWidth:760,margin:"0 auto"}}>
      <h1>Reddit MCP</h1>
      <p>Read-only MCP server for public Reddit RSS feeds.</p>
      <p>MCP endpoint: <code>/api/mcp</code></p>
    </main>
  );
}